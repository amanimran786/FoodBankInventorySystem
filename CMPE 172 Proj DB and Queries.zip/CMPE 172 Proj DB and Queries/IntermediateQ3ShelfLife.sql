SELECT fi.Item_Name, fi.Shelf_Life_Days, ie.Expiration_Date
FROM Inventory_Entry ie
JOIN Food_Item fi ON ie.Item_ID = fi.Item_ID
WHERE ie.Expiration_Date <= DATE('2025-10-29');
