INSERT INTO Donor (DonorID, Name, Type, email) VALUES
(1, 'Whole Foods', 'Organization', 'contact@wholefoods.com'),
(2, 'John Doe', 'Individual', 'john.doe@example.com'),
(3, 'Walmart', 'Organization', 'help@walmart.com'),
(4, 'Jane Smith', 'Individual', 'jane.smith@example.com'),
(5, 'Trader Joe\'s', 'Organization', 'support@traderjoes.com'),
(6, 'Bob Johnson', 'Individual', 'bob.johnson@email.com'),
(7, 'Costco', 'Organization', 'info@costco.com'),
(8, 'Alice Brown', 'Individual', 'alice.brown@mail.com'),
(9, 'Kroger', 'Organization', 'kroger@donate.com'),
(10, 'Tom White', 'Individual', 'tom.white@charity.org');
