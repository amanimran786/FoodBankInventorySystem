SELECT DI.item_ID, SUM(DI.quantity_given) AS TotalDistributed
FROM Distributed_Item DI
GROUP BY DI.item_ID;
