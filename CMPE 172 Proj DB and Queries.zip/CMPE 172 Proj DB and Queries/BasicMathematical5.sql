SELECT DISTINCT bank_ID FROM Foodbank_Inventory;
