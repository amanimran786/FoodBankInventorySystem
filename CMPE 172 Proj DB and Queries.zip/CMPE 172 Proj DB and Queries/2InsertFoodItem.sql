INSERT INTO Food_Item (Item_ID, Item_Name, Category, Shelf_Life_Days) VALUES
(1, 'Canned Beans', 'Canned Goods', 365),
(2, 'Rice', 'Grains', 730),
(3, 'Pasta', 'Grains', 540),
(4, 'Cereal', 'Breakfast', 365),
(5, 'Tomato Sauce', 'Canned Goods', 300),
(6, 'Peanut Butter', 'Spreads', 600),
(7, 'Oats', 'Grains', 730),
(8, 'Soup', 'Canned Goods', 365),
(9, 'Milk Powder', 'Dairy', 180),
(10, 'Granola Bars', 'Snacks', 150);
