INSERT INTO Recipient (Recipient_ID, name) VALUES
(1, 'Anna Taylor'),
(2, 'Chris Green'),
(3, 'Leo Smith'),
(4, 'Zara Khan'),
(5, 'Henry Moore'),
(6, 'Olivia Brown'),
(7, 'Mason Clark'),
(8, 'Isabella Adams'),
(9, 'Jack Lee'),
(10, 'Sophia King');
