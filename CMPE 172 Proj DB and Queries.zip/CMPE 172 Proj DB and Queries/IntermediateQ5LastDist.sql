SELECT r.name AS Recipient_Name, MAX(d.Distribution_Date) AS Last_Distribution
FROM Distribution d
JOIN Recipient r ON d.Recipient_ID = r.Recipient_ID
GROUP BY r.name
ORDER BY Last_Distribution DESC;
