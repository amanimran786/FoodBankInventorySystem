SELECT FB.name, SUM(DI.quantity_given) AS TotalQuantity
FROM Food_Bank FB
JOIN Distribution D ON FB.bank_ID = D.bank_ID
JOIN Distributed_Item DI ON D.distribution_ID = DI.distribution_ID
JOIN Food_Item FI ON DI.item_ID = FI.Item_ID
WHERE FI.Category = 'Canned Goods'
GROUP BY FB.name
ORDER BY TotalQuantity DESC
LIMIT 1;
