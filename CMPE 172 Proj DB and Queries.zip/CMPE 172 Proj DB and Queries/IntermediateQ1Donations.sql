SELECT fi.Item_Name, d.name AS Donor_Name, ie.Quantity
FROM Inventory_Entry ie
JOIN Food_Item fi ON ie.Item_ID = fi.Item_ID
JOIN Donor d ON ie.Donor_ID = d.Donor_ID;
