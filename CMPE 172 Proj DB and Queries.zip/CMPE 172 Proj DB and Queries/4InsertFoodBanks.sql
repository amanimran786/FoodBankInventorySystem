INSERT INTO Food_Bank (bank_ID, name, address, email, phone_number) VALUES
(1, 'Northside Food Bank', '123 North St', 'north@foodbank.org', '555-1001'),
(2, 'East End Food Bank', '456 East St', 'east@foodbank.org', '555-1002'),
(3, 'South Valley Bank', '789 South Ave', 'south@foodbank.org', '555-1003'),
(4, 'West Hill Food Bank', '101 West Rd', 'west@foodbank.org', '555-1004'),
(5, 'Midtown Food Center', '202 Center St', 'midtown@foodbank.org', '555-1005'),
(6, 'Riverside Pantry', '303 River Rd', 'riverside@foodbank.org', '555-1006'),
(7, 'Greenfield Bank', '404 Green Rd', 'green@foodbank.org', '555-1007'),
(8, 'Downtown Relief Center', '505 Main St', 'downtown@foodbank.org', '555-1008'),
(9, 'Hillside Pantry', '606 Hilltop Blvd', 'hillside@foodbank.org', '555-1009'),
(10, 'Oakwood Food Bank', '707 Oak St', 'oakwood@foodbank.org', '555-1010');
