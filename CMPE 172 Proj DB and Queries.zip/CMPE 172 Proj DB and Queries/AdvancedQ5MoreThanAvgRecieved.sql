SELECT R.name, SUM(DI.quantity_given) AS TotalReceived
FROM Recipient R
JOIN Distribution D ON R.Recipient_ID = D.recipient_ID
JOIN Distributed_Item DI ON D.distribution_ID = DI.distribution_ID
GROUP BY R.name
HAVING SUM(DI.quantity_given) > (
    SELECT AVG(TotalGiven)
    FROM (
        SELECT SUM(DI2.quantity_given) AS TotalGiven
        FROM Distribution D2
        JOIN Distributed_Item DI2 ON D2.distribution_ID = DI2.distribution_ID
        GROUP BY D2.recipient_ID
    ) AS AvgTable
)
ORDER BY TotalReceived DESC;
