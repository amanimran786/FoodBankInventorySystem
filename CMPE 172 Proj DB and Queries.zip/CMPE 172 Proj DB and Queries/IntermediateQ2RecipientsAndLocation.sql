SELECT r.name AS Recipient_Name, fb.name AS Food_Bank_Name
FROM Distribution d
JOIN Recipient r ON d.Recipient_ID = r.Recipient_ID
JOIN Food_Bank fb ON d.bank_ID = fb.bank_ID;
