SELECT Item_Name FROM Food_Item;
