SELECT name, address
FROM Food_Bank
ORDER BY name;
