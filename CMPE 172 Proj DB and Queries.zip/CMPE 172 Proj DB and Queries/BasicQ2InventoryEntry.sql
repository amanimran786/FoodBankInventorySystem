SELECT Item_ID, COUNT(*) AS EntryCount
FROM Inventory_Entry
GROUP BY Item_ID;
