SELECT FB.name, MAX(TotalQuantity) AS MaxDistributedItemQuantity
FROM Food_Bank FB
JOIN (
    SELECT D.bank_ID, DI.item_ID, SUM(DI.quantity_given) AS TotalQuantity
    FROM Distribution D
    JOIN Distributed_Item DI ON D.distribution_ID = DI.distribution_ID
    GROUP BY D.bank_ID, DI.item_ID
) AS SubQuery
ON FB.bank_ID = SubQuery.bank_ID
GROUP BY FB.name;
