INSERT INTO Distributed_Item (distribution_ID, item_ID, quantity_given) VALUES
(1, 1, 10),
(2, 2, 15),
(3, 3, 20),
(4, 4, 25),
(5, 5, 12),
(6, 6, 30),
(7, 7, 8),
(8, 8, 16),
(9, 9, 14),
(10, 10, 18);
