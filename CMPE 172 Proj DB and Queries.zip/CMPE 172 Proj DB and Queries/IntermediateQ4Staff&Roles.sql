SELECT s.name AS Staff_Name, s.role, fb.name AS Food_Bank
FROM Staff s
JOIN Food_Bank fb ON s.bank_ID = fb.bank_ID;
