SELECT name
FROM Recipient
WHERE name LIKE 'S%';
