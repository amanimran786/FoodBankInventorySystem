SELECT D.Name, SUM(DI.quantity_given) AS TotalDistributed
FROM Donor D
JOIN Inventory_Entry IE ON D.DonorID = IE.Donor_ID
JOIN Distributed_Item DI ON IE.Item_ID = DI.item_ID
GROUP BY D.Name
HAVING SUM(DI.quantity_given) > (
    SELECT AVG(TotalQuantity)
    FROM (
        SELECT SUM(DI2.quantity_given) AS TotalQuantity
        FROM Donor D2
        JOIN Inventory_Entry IE2 ON D2.DonorID = IE2.Donor_ID
        JOIN Distributed_Item DI2 ON IE2.Item_ID = DI2.item_ID
        GROUP BY D2.DonorID
    ) AS AvgSubQuery
)
ORDER BY TotalDistributed DESC
LIMIT 3;
