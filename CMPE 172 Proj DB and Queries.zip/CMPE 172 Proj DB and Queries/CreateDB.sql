CREATE DATABASE foodbank;
USE foodbank;

-- Donor Table
CREATE TABLE Donor (
    DonorID INT PRIMARY KEY,
    Name VARCHAR(100),
    Type VARCHAR(50),
    email VARCHAR(100)
);

-- Food_Item Table
CREATE TABLE Food_Item (
    Item_ID INT PRIMARY KEY,
    Item_Name VARCHAR(100),
    Category VARCHAR(50),
    Shelf_Life_Days INT
);

-- Inventory_Entry Table
CREATE TABLE Inventory_Entry (
    Inventory_ID INT PRIMARY KEY,
    Item_ID INT,
    Donor_ID INT,
    Quantity INT,
    Date_Received DATE,
    Expiration_Date DATE,
    FOREIGN KEY (Item_ID) REFERENCES Food_Item(Item_ID),
    FOREIGN KEY (Donor_ID) REFERENCES Donor(DonorID)
);

-- Food_Bank Table
CREATE TABLE Food_Bank (
    bank_ID INT PRIMARY KEY,
    name VARCHAR(100),
    address VARCHAR(200),
    email VARCHAR(100),
    phone_number VARCHAR(20)
);

-- Staff Table
CREATE TABLE Staff (
    staff_ID INT PRIMARY KEY,
    name VARCHAR(100),
    role VARCHAR(50),
    phone_number VARCHAR(20),
    email VARCHAR(100),
    bank_ID INT,
    FOREIGN KEY (bank_ID) REFERENCES Food_Bank(bank_ID)
);

-- Foodbank_Inventory Table
CREATE TABLE Foodbank_Inventory (
    bank_InventoryID INT PRIMARY KEY,
    bank_ID INT,
    inventory_ID INT,
    date_stocked DATE,
    FOREIGN KEY (bank_ID) REFERENCES Food_Bank(bank_ID),
    FOREIGN KEY (inventory_ID) REFERENCES Inventory_Entry(Inventory_ID)
);

-- Recipient Table
CREATE TABLE Recipient (
    Recipient_ID INT PRIMARY KEY,
    name VARCHAR(100)
);

-- Distribution Table
CREATE TABLE Distribution (
    distribution_ID INT PRIMARY KEY,
    recipient_ID INT,
    bank_ID INT,
    distribution_date DATE,
    FOREIGN KEY (recipient_ID) REFERENCES Recipient(Recipient_ID),
    FOREIGN KEY (bank_ID) REFERENCES Food_Bank(bank_ID)
);

-- Distributed_Item Table
CREATE TABLE Distributed_Item (
    distribution_ID INT,
    item_ID INT,
    quantity_given INT,
    PRIMARY KEY (distribution_ID, item_ID),
    FOREIGN KEY (distribution_ID) REFERENCES Distribution(distribution_ID),
    FOREIGN KEY (item_ID) REFERENCES Food_Item(Item_ID)
);
