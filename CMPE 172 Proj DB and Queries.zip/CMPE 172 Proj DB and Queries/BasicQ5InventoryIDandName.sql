SELECT Inventory_Entry.Inventory_ID, Food_Item.Item_Name
FROM Inventory_Entry
JOIN Food_Item ON Inventory_Entry.Item_ID = Food_Item.Item_ID
WHERE Quantity > 100;
