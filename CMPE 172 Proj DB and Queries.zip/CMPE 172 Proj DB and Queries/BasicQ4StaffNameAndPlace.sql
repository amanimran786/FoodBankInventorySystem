SELECT Staff.name, Food_Bank.name AS FoodBank
FROM Staff
JOIN Food_Bank ON Staff.bank_ID = Food_Bank.bank_ID;
