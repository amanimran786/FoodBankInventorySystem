INSERT INTO Staff (staff_ID, name, role, phone_number, email, bank_ID) VALUES
(1, 'Emily Stone', 'Manager', '555-2001', 'emily@northbank.org', 1),
(2, 'Mark Dean', 'Coordinator', '555-2002', 'mark@eastbank.org', 2),
(3, 'Rachel Lee', 'Volunteer', '555-2003', 'rachel@southbank.org', 3),
(4, 'James Bond', 'Driver', '555-2004', 'james@westbank.org', 4),
(5, 'Linda Hill', 'Assistant', '555-2005', 'linda@midtownbank.org', 5),
(6, 'Kevin Wu', 'Volunteer', '555-2006', 'kevin@riverside.org', 6),
(7, 'Nancy Drew', 'Coordinator', '555-2007', 'nancy@greenfield.org', 7),
(8, 'Peter Parker', 'Driver', '555-2008', 'peter@downtown.org', 8),
(9, 'Susan Clark', 'Assistant', '555-2009', 'susan@hillside.org', 9),
(10, 'Bruce Wayne', 'Manager', '555-2010', 'bruce@oakwood.org', 10);
