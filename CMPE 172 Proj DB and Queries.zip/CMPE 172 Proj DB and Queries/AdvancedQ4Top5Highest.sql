SELECT FB.name, SUM(DI.quantity_given) AS TotalDistributed
FROM Food_Bank FB
JOIN Distribution D ON FB.bank_ID = D.bank_ID
JOIN Distributed_Item DI ON D.distribution_ID = DI.distribution_ID
GROUP BY FB.name
HAVING SUM(DI.quantity_given) > (
    SELECT AVG(Total)
    FROM (
        SELECT SUM(DI2.quantity_given) AS Total
        FROM Food_Bank FB2
        JOIN Distribution D2 ON FB2.bank_ID = D2.bank_ID
        JOIN Distributed_Item DI2 ON D2.distribution_ID = DI2.distribution_ID
        GROUP BY FB2.bank_ID
    ) AS SubQuery
)
ORDER BY TotalDistributed DESC
LIMIT 5;
