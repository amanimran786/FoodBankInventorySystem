SELECT DI.item_ID, DI.quantity_given, D.distribution_date
FROM Distributed_Item DI
JOIN Distribution D ON DI.distribution_ID = D.distribution_ID
WHERE D.distribution_date BETWEEN '2025-05-01' AND '2025-05-05';
